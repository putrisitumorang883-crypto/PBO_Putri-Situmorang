/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg41425059_putri.yuni.br.situmorang_sesi2;

// Nim : 41425059
// Nama : Putri Yuni Br Situmorang
import java.util.Scanner;

public class LoginSederhana {
     public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Masukkan nama lengkap: ");
        String nama = input.nextLine();

        System.out.println("Panjang string: " + nama.length());
        System.out.println("Huruf pertama: " + nama.charAt(0));
        System.out.println("Mengandung spasi: " + nama.contains(" "));
    }
}

// - Bagaimana jika nama yang diinput dengan lebih dari satu spasi?
// Jawab: contains(" ") tetap true dan length() ikut menghitung semua spasi,
// jadi panjangnya jadi lebih besar dari jumlah huruf sebenarnya.
// Solusinya trim() untuk membuang spasi di ujung, atau replaceAll("\\s+", " ") untuk merapikan spasi ganda.

   
