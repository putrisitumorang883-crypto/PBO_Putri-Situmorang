/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg41425059_putri.yuni.br.situmorang_sesi2;

// Nim : 41425059
// Nama : Putri Yuni Br Situmorang
import java.util.Scanner;

//  Rumus luas = PI * r * r, keliling = 2 * PI * r
public class Lingkaran {    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        final double PI = 3.14; //final yaitu nilai PI tidak boleh diubah lagi (konstanta)

        System.out.print("Masukkan jari-jari: ");
        double r = input.nextDouble(); // nextDouble() membaca bilangan desimal

        //  Validasi input jari-jari tidak bernilai negatif
        if (r < 0) {
            System.out.println("Error: jari-jari tidak boleh negatif.");
        } else {
            double luas = PI * r * r;
            double keliling = 2 * PI * r;
            System.out.println("Luas: " + luas);
            System.out.println("Keliling: " + keliling);
        }
    }
}

// - Mengapa kita perlu validasi r < 0?
// Jawab: Karena Jari-jari negatif tidak ada secara fisik.
//  Rumus tetap menghasilkan angka (karena r² positif), jadi program "berjalan" tapi datanya salah — error jenis ini paling berbahaya karena tidak terdeteksi.


// -  Dalam aplikasi nyata, di mana validasi input sangat penting?
// Jawab: Validasi input sangat penting  Form pendaftaran, transaksi pembayaran (jumlah tidak boleh negatif)
//  input umur/berat di aplikasi kesehatan, dan login — untuk mencegah data rusak maupun celah keamanan.
