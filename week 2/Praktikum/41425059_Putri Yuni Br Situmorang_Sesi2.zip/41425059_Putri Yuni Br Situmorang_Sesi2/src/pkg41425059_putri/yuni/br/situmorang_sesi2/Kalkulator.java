/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg41425059_putri.yuni.br.situmorang_sesi2;

// Nim : 41425059
// Nama : Putri Yuni Br Situmorang 
import java.util.Scanner;   // unutk membaca input dari pengguna
public class Kalkulator {  
public static void main(String[] args) {
Scanner input = new Scanner(System.in); // objek scaner untuk membaca kayboard
System.out.print("Masukkan angka pertama: ");
int a = input.nextInt();      // Membaca bilangan bulat 
System.out.print("Masukkan angka kedua: ");
int b = input.nextInt();

// Operasi Aritmatika
System.out.println("Tambah: " + (a + b));
System.out.println("Kurang: " + (a - b));
System.out.println("Kali: " + (a * b));
System.out.println("Bagi: " + ((double) a / b));
}
}


 // Pertanyaan Pemantik 

// -  Praktek 1 : Apa perbedaan nilai asli double dengan hasil casting int?
// Jawab : Niali asli Yang double masih ada koma-nya, 165.8. 
// Begitu di-casting ke int, angka di belakang koma langsung dibuang, jadi 165.
// Bukan dibulatkan jadi 165.9 pun tetap jadi 165. Intinya ada data yang hilang.

// -  Praktek 2: Mengapa pembagian int perlu di-casting ke double?
// Jawab :Karena kalau dua-duanya int, Java ngitungnya juga pakai aturan int, jadi komanya dibuang.
// 12 dibagi 5 hasilnya 2, padahal harusnya 2.4. Nah dengan dikasih (double)
// di depan, Java baru mau ngasih hasil yang ada komanya.

// - Praktek 3: Apa risiko jika pembagi = 0?
// Jawab: Programnya langsung error dan berhenti, muncul ArithmeticException.
// Soalnya di matematika juga nggak ada angka dibagi nol
// Kalau tipenya double sih nggak error, tapi hasilnya Infinity yang ya nggak ada gunanya juga
// Makanya lebih aman dicek dulu pakai if (b == 0)